// Definimos un tipo para nuestro objeto de ubicaciones,
// indicando que puede ser indexado por cualquier string y devolverá un array de strings.
type LocationsType = {
  [key: string]: string[];
};

export const locationsData: LocationsType = {
  'Buenos Aires': ['Azul', 'Bahía Blanca', 'La Plata', 'Mar del Plata', 'Tandil'],
  'Córdoba': ['Río Cuarto', 'Capital', 'General San Martín', 'Villa María', 'Carlos Paz'],
  'Santa Fe': ['Rosario', 'La Capital', 'General López', 'Rafaela', 'Venado Tuerto'],
  'La Pampa': ['Capital', 'Maracó', 'Realicó', 'General Pico', 'Santa Rosa'],
  'Entre Ríos': ['Paraná', 'Concordia', 'Gualeguaychú', 'Colón', 'Uruguay'],
  'Salta': ['Anta', 'Cachi', 'Cafayate', 'Capital', 'Cerrillos', 'Chicoana', 'General Güemes', 'General San Martin', 'Iruya', 'La Caldera', 'La Candelaria', 'La Poma', 'La Viña', 'Los Andes', 'Metán', 'Molinos', 'Orán', 'Rivadavia', 'Rosario de la Frontera', 'Rosario de Lerma', 'San Carlos', 'Santa Victoria'],
  'Tucumán': ['Burruyacú', 'Capital', 'Chicligasta', 'Cruz Alta', 'Famaillá', 'Graneros', 'Juan Bautista Alberdi', 'La Cocha', 'Leales', 'Lules', 'Monteros', 'Río Chico', 'Simoca', 'Tafí del Valle', 'Tafí Viejo', 'Trancas','Yerba Buena']
};

export const provincias = Object.keys(locationsData);
