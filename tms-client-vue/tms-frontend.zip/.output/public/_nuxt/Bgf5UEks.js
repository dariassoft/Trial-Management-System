import"./BSLBp5iJ.js";const s=globalThis.setInterval;export{s};
