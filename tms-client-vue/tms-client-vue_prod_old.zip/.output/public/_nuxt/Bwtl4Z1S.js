const i=defineRouteMiddleware((a,d)=>{const s=/^\/ensayos\/(\d+)(\/edit)?$/,e=a.path.match(s);if(e){const t=e[1];e[2],a.params.id||(a.params.id=t)}});export{i as default};
